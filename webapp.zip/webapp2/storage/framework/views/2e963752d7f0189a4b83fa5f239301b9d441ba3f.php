<div class="links">
					<a href="/index">Index</a>
                    <a href="/about">about</a>
                    <a href="/service">Services</a>
                    <a href="/signin">signin</a>
                    <a href="/register">Register </a>
</div>
<?php echo $__env->yieldContent('contents'); ?>