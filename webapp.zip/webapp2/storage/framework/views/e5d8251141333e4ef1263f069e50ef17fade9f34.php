<table border=2>
	<tr>
		<td>Id</td>
		<td>Title</td>
		<td>Body</td>
		<td>Edit</td>
		<td>Delete</td>
	</tr>
		<?php $__currentLoopData = $share; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($value->id); ?></td>
		<td><?php echo e($value->title); ?></td>
		<td><?php echo e($value->body); ?></td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
