
<form method= "post" action="<?php echo e(route('Shares.store')); ?>">
	<?php echo csrf_field(); ?>
	<table border="1">
		<tr>
			<td>Title</td>
			<td><input type="text" name="title"></td>
		</tr>
		<tr>
			<td>
				Body
			</td>
			<td><input type="text" name="body"></td>
		</tr>
		<tr><td><input type="submit" name="submit" value="Click"></td></tr>
			
		</tr>
		</table>
	</form>
