<form method="post" action="{{route('shares.update',$value->id)}}">
@method('PATCH')
@csrf

<table>
<tr> 
<td>Title</td>
<td><input type="text" name="title1" value={{$value->title}}/></td>
</tr>
<tr>
<td> Body</td>
<td><input type="text" name="body" value={{$value->body}}/></td>
</tr>
<tr>
<td><input type="submit" name="submit"></td>
</tr>
</table>
</form>