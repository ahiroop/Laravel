<form method="post" action="<?php echo e(route('shares.update',$value->id)); ?>">
<?php echo method_field('PATCH'); ?>
<?php echo csrf_field(); ?>

<table>
<tr> 
<td>Title</td>
<td><input type="text" name="title1" value=<?php echo e($value->title); ?>/></td>
</tr>
<tr>
<td> Body</td>
<td><input type="text" name="body" value=<?php echo e($value->body); ?>/></td>
</tr>
<tr>
<td><input type="submit" name="submit"></td>
</tr>
</table>
</form>